<?
require($_SERVER["DOCUMENT_ROOT"]."/bitrix/modules/main/include/prolog_before.php");

// <img src="http://www.coral-club.com/po_stat_log/in_log.php?code=КОД_РАССЫЛКИ&user_id=#USER_ID#&temail=#EMAIL#"/>  - счётчик на стороне клиента, должен быть уникальный КОД_РАССЫЛКИ(латынь, цифра, дефис, подчёркивание без пробелов)
/*

// создаем обработчик события "BeforePostingSendMail"  и добавляем в /bitrix/php_interface/init.php

 AddEventHandler("subscribe", "BeforePostingSendMail", "beforePostingSendMailHandler");
 
        function beforePostingSendMailHandler($arFields){
			$arFields["BODY"] = str_replace("#EMAIL#", $arFields["EMAIL"], $arFields["BODY"]);
            //$USER_NAME = "Подписчик"; 
            //Попробуем найти подписчика. 
            $rs = CSubscription::GetByEmail($arFields["EMAIL"]);
            if($ar = $rs->Fetch()){
              
                $arFields["BODY"] = str_replace("#CONFIRM_CODE#", $ar["CONFIRM_CODE"], $arFields["BODY"]);
                $arFields["BODY"] = str_replace("#ID#", $ar["ID"], $arFields["BODY"]);
                $arFields["BODY"] = str_replace("#USER_EMAIL#", $ar["EMAIL"], $arFields["BODY"]);
				$arFields["BODY"] = str_replace("#USER_ID#", $ar["USER_ID"], $arFields["BODY"]);
            }
            //$arFields["BODY"] = str_replace("#NAME#", $USER_NAME, $arFields["BODY"]); 
			
            return $arFields;
        }

*/
$image = imagecreatetruecolor(1,1)
   or die('Cannot create image');

	imagefill($image, 0, 0, 0xffffff);

// счетчик
$rsUser = CUser::GetByID($_GET["user_id"]);
$arUser = $rsUser->Fetch();
			
$file = fopen ($_SERVER['DOCUMENT_ROOT']."/po_stat_log/posting_".$_GET["code"].".txt","a+");
if($file ) {
	$str = $_GET["code"]."; ".date("d.m.Y H:i:s")."; ".$temail."; ".$arUser["LAST_NAME"]."; ".$arUser["NAME"]."; ".$arUser["LOGIN"]."; ".$_GET["user_id"]."\r\n";
	fwrite( $file, $str);
	fclose ($file);
}
header('Content-type: image/png');
imagepng($image);
imagedestroy($image);

require($_SERVER["DOCUMENT_ROOT"]."/bitrix/modules/main/include/epilog_after.php");
?>